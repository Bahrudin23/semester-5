import 'package:flutter/material.dart';

void main() {
  runApp(const HaloDuniaku());
}

class HaloDuniaku extends StatefulWidget {
  const HaloDuniaku({super.key});

  @override
  State<HaloDuniaku> createState() => _HaloDuniakuState();
}

class _HaloDuniakuState extends State<HaloDuniaku> {
  bool tampilkanGambar = false;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.yellow,
          title: Image.network(
            'https://upload.wikimedia.org/wikipedia/commons/e/e7/Unipdujombang.png',
            width: 150,
            height: 150,
            fit: BoxFit.contain,
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.home, color: Colors.red, size: 28),
              onPressed: () {
                setState(() {
                  tampilkanGambar = false;
                });
              },
              tooltip: 'Kembali',
            ),
          ],
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (tampilkanGambar)
                Image.asset(
                  'images/alam.jpeg',
                  width: 800,
                  height: 450,
                  fit: BoxFit.cover,
                ),
              const SizedBox(height: 5),
              if (!tampilkanGambar)
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      tampilkanGambar = true;
                    });
                  },
                  child: const Text(
                    'Click Me!',
                    style: TextStyle(fontSize: 16),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
